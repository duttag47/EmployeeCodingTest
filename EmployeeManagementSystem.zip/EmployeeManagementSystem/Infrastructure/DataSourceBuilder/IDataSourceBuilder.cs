﻿using System;
using ApplicationCore.CustomException;
using ApplicationCore.Model;
using Infrastructure.Repository;

namespace Infrastructure.DataSourceBuilder
{
    public interface IDataSourceBuilder<TEntity> where TEntity : Entity
    {
        /// <summary>
        ///     Set DataSource
        /// </summary>
        /// <param name="dataSource">DataSource</param>
        void SetDataSource(Source dataSource);

        /// <summary>
        ///     Set file path for DataSource dealing with file based repository implementaion.
        ///     If not provided it will look for file name in executing directory with TEntity name
        ///     and if  file does not exist it will create a new file in executing directory.
        /// </summary>
        /// <param name="path">File path.</param>
        void SetFilePath(string path);

        /// <summary>
        ///     Build repository instance based on provided
        /// </summary>
        /// <returns>Returns implementation of <see cref="IRepository{TEntity}"></returns>
        /// <exceptions cref="InvalidDataSourceException">If datasource file has exception.</exceptions>
        /// <exceptions cref="Exception">Any unhandelled exception while initiating repository instance.</exceptions>
        IRepository<TEntity> Build();
    }
}