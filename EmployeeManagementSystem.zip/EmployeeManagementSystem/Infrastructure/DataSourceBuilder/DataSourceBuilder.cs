﻿using System;
using ApplicationCore;
using ApplicationCore.CustomException;
using ApplicationCore.Model;
using Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.DataSourceBuilder
{
    public class DataSourceBuilder<TEntity> : IDataSourceBuilder<TEntity> where TEntity : Entity
    {
        public DataSourceBuilder(IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
        }

        private IServiceProvider ServiceProvider { get; }

        public Source DataSource { get; private set; }

        public string Path { get; private set; }

        /// <summary>
        ///     Build repository instance based on provided <see cref="Source">.
        /// </summary>
        /// <returns>Returns implementation of <see cref="IRepository{TEntity}"></returns>
        /// <exceptions cref="InvalidDataSourceException">If data source file has exception.</exceptions>
        /// <exceptions cref="Exception">Any unhandelled exception while initiating repository instance.</exceptions>
        public IRepository<TEntity> Build()
        {
            IRepository<TEntity> repository = null;
            try
            {
                var repositoryResolver = ServiceProvider.GetService<Func<DataSource, IRepository<TEntity>>>();
                switch (DataSource)
                {
                    case Source.XML:
                        var xmlFilePath = string.IsNullOrWhiteSpace(Path)
                            ? $"{typeof(TEntity).Name}{FileExtension.XmlFileType}"
                            : System.IO.Path.Combine(Path, $"{typeof(TEntity).Name}{FileExtension.XmlFileType}");
                        repository = repositoryResolver(new DataSource
                            {Source = DataSource, FilePath = xmlFilePath});
                        break;
                    case Source.InMemory:
                        repository = repositoryResolver(new DataSource
                            {Source = DataSource, FilePath = null});
                        break;
                    default:
                        throw new InvalidDataSourceException("Invalid data source.");
                }
            }
            catch (Exception)
            {
                // Log and Rethrow/Handle the exception.
            }

            return repository;
        }

        /// <summary>
        ///     Set file path for DataSource dealing with file based repository implementation.
        ///     If not provided it will look for file name in executing directory with TEntity name
        ///     and if  file does not exist it will create a new file in executing directory with TEntity name.
        /// </summary>
        /// <param name="path">File path.</param>
        public void SetFilePath(string path)
        {
            Path = path;
        }

        /// <summary>
        ///     Set DataSource for which <see cref="IRepository{TEntity}" /> implementation is expected.
        /// </summary>
        /// <param name="dataSource">DataSource</param>
        public void SetDataSource(Source dataSource)
        {
            DataSource = dataSource;
        }
    }
}