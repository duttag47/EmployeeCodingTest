﻿namespace Infrastructure.DataSourceBuilder
{
    public enum Source
    {
        XML,
        InMemory
    }
}