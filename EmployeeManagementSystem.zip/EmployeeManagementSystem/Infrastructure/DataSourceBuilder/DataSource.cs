﻿namespace Infrastructure.DataSourceBuilder
{
    public class DataSource
    {
        public Source Source { get; set; }

        public string FilePath { get; set; }
    }
}