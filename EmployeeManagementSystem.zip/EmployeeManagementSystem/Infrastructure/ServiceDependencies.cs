﻿using System;
using ApplicationCore.Model;
using Infrastructure.DataSourceBuilder;
using Infrastructure.Extension;
using Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure
{
    public static class ServiceDependencies
    {
        public static IServiceCollection AddSevices()
        {
            IServiceCollection services = new ServiceCollection();
            services.AddRepoistoryDependencies<Employee>();
            services.AddTransient<Func<Source, string, IEmployeeRepository>>(
                serviceProvider => (dataSource, filepath) =>
                {
                    return dataSource switch
                    {
                        var source when
                        source == Source.XML => new EmployeeRepository(serviceProvider, dataSource, filepath),
                        Source.InMemory => new EmployeeRepository(serviceProvider, dataSource)
                    };
                });

            return services;
        }
    }
}