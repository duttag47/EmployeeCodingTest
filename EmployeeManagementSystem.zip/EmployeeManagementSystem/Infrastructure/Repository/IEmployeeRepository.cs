﻿using System.Collections.Generic;
using ApplicationCore.Model;

namespace Infrastructure.Repository
{
    public interface IEmployeeRepository
    {
        void Add(Employee entity);

        Employee Get(int id);

        IEnumerable<Employee> GetAll();

        void Delete(int id);

        void Update(Employee entity);
    }
}