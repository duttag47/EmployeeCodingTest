﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using ApplicationCore.CustomException;
using ApplicationCore.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using ErrorEventArgs = Newtonsoft.Json.Serialization.ErrorEventArgs;

namespace Infrastructure.Repository
{
    public sealed class XmlRepository<TEntity> : IRepository<TEntity>
        where TEntity : Entity
    {
        readonly List<string> errors = new List<string>();
        private readonly string filePath;

        private XElement fileContext;

        private Random random;

        /// <summary>
        ///     Creates instance of Repository.
        /// </summary>
        /// <param name="file">XMLFile</param>
        public XmlRepository(string file)
        {
            filePath = file;
            Initialize();
        }

        /// <summary>
        ///     Gets the selector to de-serealize from XElement to TEntity
        /// </summary>
        private Func<XElement, TEntity> Selector
        {
            get
            {
                return x =>
                {
                    var entity = JsonConvert.DeserializeObject<TEntity>(
                        JObject.Parse(JsonConvert.SerializeXNode(x))[typeof(TEntity).Name.ToLower()]
                            .ToString(),
                        new JsonSerializerSettings
                        {
                            Error = delegate(object sender, ErrorEventArgs args)
                            {
                                errors.Add(args.ErrorContext.Error.Message);
                                args.ErrorContext.Handled = true;
                            }
                        });

                    return entity;
                };
            }
        }

        /// <summary>
        ///     Add TEntity to XML file
        /// </summary>
        /// <param name="entity">TEntity</param>
        public void Add(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            if (entity.Id == 0)
            {
                entity.Id = random.Next();
            }

            var type = entity.GetType();

            var xElements = new List<XElement>();

            var propertyNames = type.GetProperties().Select(p => p.Name);
            if (propertyNames.Any())
            {
                foreach (var name in propertyNames)
                {
                    object propValue = entity.GetType().GetProperty(name).GetValue(entity, null);
                    if (propValue.GetType().IsClass && propValue.GetType() != typeof(string))
                    {
                        xElements.Add(GetXelements(propValue));
                    }
                    else
                    {
                        xElements.Add(new XElement(name.ToLower(), propValue));
                    }
                }
            }

            fileContext.Add(new XElement(type.Name.ToLower(), xElements));

            fileContext.Save(filePath);
        }

        /// <summary>
        ///     Delete entity by Id.
        /// </summary>
        /// <param name="id">Id</param>
        public void Delete(int id)
        {
            var entities = from entity in fileContext.Elements()
                where (int) entity.Element("id") == id
                select entity;

            if (!entities.Any()) return;

            entities.Remove();
            fileContext.Save(filePath);
        }

        /// <summary>
        ///     Get all TEnities by Id.
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>List of TEntity</returns>
        public TEntity Get(int id)
        {
            var entities = from entity in fileContext.Elements()
                where Convert.ToInt32(entity.Element("id").Value) == id
                select entity;

            var entityList = entities.Select(Selector);

            if (entityList.Count() > 0 && errors.Count > 0)
            {
                // Throw exception
                throw new JsonReaderException(string.Join(";", errors));
            }

            return entityList.FirstOrDefault();
        }

        /// <summary>
        ///     GetAll TEntities
        /// </summary>
        /// <returns>List of TEntity</returns>
        public IEnumerable<TEntity> GetAll()
        {
            var entityList = fileContext.Elements().Select(Selector);

            if (errors.Count > 0)
            {
                // Log error or throw error.
                Console.WriteLine($"Errors - {string.Join(";", errors)}");
            }

            return entityList;
        }

        /// <summary>
        ///     Update provided entity.
        /// </summary>
        /// <param name="entity">TEntity</param>
        public void Update(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            Delete(entity.Id);
            Add(entity);
        }

        private void Initialize()
        {
            try
            {
                fileContext = File.Exists(filePath) ? XElement.Load(filePath) : new XElement(filePath);

                random = new Random();
            }
            catch (XmlException xmlException)
            {
                // Log exception
                throw new InvalidDataSourceException($"Invalid XML data exception. Error : {xmlException.Message}");
            }
            catch (Exception exception)
            {
                // Log and throw exception further or Handle the exception.
                throw exception;
            }
        }

        private XElement GetXelements(object entity)
        {
            var xElements = new List<XElement>();
            var propertyNames = entity.GetType().GetProperties().Select(p => p.Name);
            if (propertyNames.Any())
            {
                foreach (var name in propertyNames)
                {
                    var propValue = entity.GetType().GetProperty(name).GetValue(entity, null);

                    if (propValue.GetType().IsClass && propValue.GetType() != typeof(string))
                    {
                        xElements.Add(GetXelements(propValue));
                    }
                    else
                    {
                        xElements.Add(new XElement(name.ToLower(), propValue));
                    }
                }
            }

            return new XElement(entity.GetType().Name.ToLower(), xElements);
        }
    }
}