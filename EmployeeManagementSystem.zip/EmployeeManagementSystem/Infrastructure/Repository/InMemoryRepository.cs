﻿using System;
using System.Collections.Generic;
using System.Linq;
using ApplicationCore.Model;

namespace Infrastructure.Repository
{
    public sealed class InMemoryRepository<TEntity> : IRepository<TEntity>
        where TEntity : Entity
    {
        private readonly Dictionary<string, TEntity> db = new Dictionary<string, TEntity>();
        private readonly Random random;
        public int Count => db.Count;

        /// <summary>
        ///     GetAll TEntities
        /// </summary>
        /// <returns>List of TEntity</returns>
        public IEnumerable<TEntity> GetAll()
        {
            return db.Values.AsEnumerable();
        }

        /// <summary>
        ///     Get Entity by Id.
        /// </summary>
        /// <param name="id"></param>
        /// <returns>List of TEntity</returns>
        public TEntity Get(int id)
        {
            return db.ContainsKey(id.ToString()) ? db[id.ToString()] : default;
        }

        /// <summary>
        ///     Add TEntity to in memory repo
        /// </summary>
        /// <param name="entity">TEntity</param>
        public void Add(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            if (entity.Id == 0)
            {
                entity.Id = random.Next();
            }

            db[entity.Id.ToString()] = entity;
        }

        /// <summary>
        ///     Update provided entity.
        /// </summary>
        /// <param name="entity">TEntity</param>
        public void Update(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }

            var id = entity.Id;
            db[id.ToString()] = entity;
        }

        /// <summary>
        ///     Delete entity by id
        /// </summary>
        /// <param name="id"></param>
        public void Delete(int id)
        {
            if (db.ContainsKey(id.ToString()))
            {
                db.Remove(id.ToString());
            }
        }
    }
}