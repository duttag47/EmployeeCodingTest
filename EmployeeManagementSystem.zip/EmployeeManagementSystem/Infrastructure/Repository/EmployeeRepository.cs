﻿using System;
using System.Collections.Generic;
using ApplicationCore.Model;
using Infrastructure.DataSourceBuilder;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.Repository
{
    public class EmployeeRepository : IEmployeeRepository
    {
        private readonly IRepository<Employee> baseRepository;

        private readonly IServiceProvider serviceProvider;

        public EmployeeRepository(IServiceProvider serviceProvider, Source dataSource, string filePath)
        {
            this.serviceProvider = serviceProvider;
            baseRepository = BuildRepository(dataSource, filePath);
        }

        public EmployeeRepository(IServiceProvider serviceProvider, Source dataSource)
        {
            this.serviceProvider = serviceProvider;
            baseRepository = BuildRepository(dataSource, string.Empty);
        }

        public void Add(Employee entity)
        {
            baseRepository.Add(entity);
        }

        public Employee Get(int id)
        {
            return baseRepository.Get(id);
        }

        public IEnumerable<Employee> GetAll()
        {
            return baseRepository.GetAll();
        }

        public void Delete(int id)
        {
            baseRepository.Delete(id);
        }

        public void Update(Employee employee)
        {
            baseRepository.Update(employee);
        }

        private IRepository<Employee> BuildRepository(Source dataSource, string filePath)
        {
            var dataSourceBuilder = serviceProvider.GetService<IDataSourceBuilder<Employee>>();
            dataSourceBuilder.SetDataSource(dataSource);
            dataSourceBuilder.SetFilePath(filePath);
            return dataSourceBuilder.Build();
        }
    }
}