﻿using System.Collections.Generic;
using ApplicationCore.Model;

namespace Infrastructure.Repository
{
    public interface IRepository<TEntity>
        where TEntity : Entity
    {
        /// <summary>
        ///     Add TEntity to XML file
        /// </summary>
        /// <param name="entity">TEntity</param>
        void Add(TEntity entity);

        /// <summary>
        ///     Get all TEnities by Id.
        /// </summary>
        /// <param name="id">Id</param>
        /// <returns>List of TEntity</returns>
        TEntity Get(int id);

        /// <summary>
        ///     GetAll TEntities
        /// </summary>
        /// <returns>List of TEntity</returns>
        IEnumerable<TEntity> GetAll();

        /// <summary>
        ///     Delete entity by Id.
        /// </summary>
        /// <param name="id">Id</param>
        void Delete(int id);

        /// <summary>
        ///     Update provided entity.
        /// </summary>
        /// <param name="entity">TEntity</param>
        void Update(TEntity entity);
    }
}