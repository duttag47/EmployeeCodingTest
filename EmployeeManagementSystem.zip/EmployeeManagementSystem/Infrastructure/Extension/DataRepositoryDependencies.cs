﻿using System;
using ApplicationCore.Model;
using Infrastructure.DataSourceBuilder;
using Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Infrastructure.Extension
{
    public static class DataRepositoryDependencies
    {
        public static void AddRepoistoryDependencies<TEntity>(this IServiceCollection services) where TEntity : Entity
        {
            services.AddTransient<IDataSourceBuilder<TEntity>, DataSourceBuilder<TEntity>>();
            services.AddTransient<Func<DataSource, IRepository<TEntity>>>(
                serviceProvider => dataSource =>
                {
                    return dataSource.Source switch
                    {
                        Source.XML => new XmlRepository<TEntity>(dataSource.FilePath),
                        Source.InMemory => new InMemoryRepository<TEntity>(),
                        _ => throw new NotImplementedException()
                    };
                });
        }
    }
}