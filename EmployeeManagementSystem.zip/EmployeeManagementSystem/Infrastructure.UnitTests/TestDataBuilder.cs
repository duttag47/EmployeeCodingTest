using System.Collections.Generic;
using ApplicationCore.Model;

namespace Infrastructure.UnitTests
{
    public static class TestDataBuilder
    {
        public static ICollection<Employee> BuildDefaultEmployeesData()
        {
            return new List<Employee>
            {
                BuildEmployee(1, "emp 1", 25, "SSE", new Address {City = "city"},
                    new Qualification {Graduation = "B.tech"}),
                BuildEmployee(2, "emp 2", 28, "SSE", new Address {City = "city"},
                    new Qualification {Graduation = "B.tech"}),
                BuildEmployee(3, "emp 3", 24, "SSE", new Address {City = "city"},
                    new Qualification {Graduation = "B.tech"}),
                BuildEmployee(4, "emp 4", 29, "SSE", new Address {City = "city"},
                    new Qualification {Graduation = "B.tech"})
            };
        }

        public static Employee BuildEmployee(int id, string name, int age, string designation, Address address,
            Qualification qualification)
        {
            return new Employee
            {
                Id = id,
                Age = age,
                Designation = designation,
                Name = name,
                Address = address,
                Qualification = qualification
            };
        }
    }
}