using Infrastructure.Repository;

namespace Infrastructure.UnitTests
{
    public static class TestHarness
    {
        public static void BuildDefaultEmployees(IEmployeeRepository empRepository)
        {
            var employees = TestDataBuilder.BuildDefaultEmployeesData();
            foreach (var employee in employees)
            {
                empRepository.Add(employee);
            }
        }

        public static void ClearEmployeesData(IEmployeeRepository empRepository)
        {
            var allEmployees = empRepository.GetAll();
            foreach (var employee in allEmployees)
            {
                empRepository.Delete(employee.Id);
            }
        }
    }
}