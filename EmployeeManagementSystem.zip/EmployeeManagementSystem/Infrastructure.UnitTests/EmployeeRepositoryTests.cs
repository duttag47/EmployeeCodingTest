using System;
using System.Linq;
using ApplicationCore.Model;
using Infrastructure.DataSourceBuilder;
using Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;
using NUnit.Framework;
using Shouldly;

namespace Infrastructure.UnitTests
{
    public class EmployeeRepositoryTests
    {
        private Func<Source, string, IEmployeeRepository> employeeResolver;
        private IEmployeeRepository sut;

        [SetUp]
        public void Setup()
        {
            var services = ServiceDependencies.AddSevices();
            using var serviceProvider = services.BuildServiceProvider();
            employeeResolver = serviceProvider.GetService<Func<Source, string, IEmployeeRepository>>();
            sut = employeeResolver(Source.InMemory, string.Empty);
        }

        [Test]
        public void Add_ShouldAddEmployee_WhenDataIsValid()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            var employee = TestDataBuilder.BuildEmployee(1, "emp 1", 25, "SSE", new Address { Town = "town"},
                new Qualification {Graduation = "B.tech"});

            // Act
            sut.Add(employee);
            var result = sut.Get(employee.Id);

            // Assert
            result.ShouldNotBeNull();
            result.Id.ShouldBe(1);
            result.Age.ShouldBe(25);
            result.Name.ShouldBe("emp 1");
            result.Designation.ShouldBe("SSE");
            result.Qualification.Graduation.ShouldBe("B.tech");
            result.Address.Town.ShouldBe("town");
        }

        [Test]
        public void GetById_ShouldGetEmployeeById_WhenDataExistsForTheId()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            var employee = TestDataBuilder.BuildEmployee(1, "emp 1", 25, "SSE", new Address { Town = "town"},
                new Qualification {Graduation = "B.tech"});
            sut.Add(employee);

            // Act
            var result = sut.Get(employee.Id);

            // Assert
            result.ShouldNotBeNull();
            result.Id.ShouldBe(1);
            result.Age.ShouldBe(25);
            result.Name.ShouldBe("emp 1");
            result.Designation.ShouldBe("SSE");
            result.Qualification.Graduation.ShouldBe("B.tech");
            result.Address.Town.ShouldBe("town");
        }

        [Test]
        public void GetAll_ShouldReturnAllEmployees_WhenDataIsAvailable()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            TestHarness.BuildDefaultEmployees(sut);
            var expectedEmployeesCount = TestDataBuilder.BuildDefaultEmployeesData().Count;
            // Act
            var result = sut.GetAll();

            // Assert
            result.ShouldNotBeNull();
            result.Count().ShouldBe(expectedEmployeesCount);
        }

        [Test]
        public void GetAll_ShouldReturnNoData_WhenDataIsNotAvailable()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            // Act
            var result = sut.GetAll();

            // Assert
            result.ShouldNotBeNull();
            result.Count().ShouldBe(0);
        }

        [Test]
        public void Delete_ShouldDeleteEmployeeById_WhenDataExistsForTheId()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            var employee = TestDataBuilder.BuildEmployee(1, "emp 1", 25, "SSE", new Address { Town = "town"},
                new Qualification {Graduation = "B.tech"});
            sut.Add(employee);

            // Act
            sut.Delete(employee.Id);
            var result = sut.Get((employee.Id));

            // Assert
            result.ShouldBeNull();
        }


        [Test]
        public void Update_ShouldUpdateEmployee_WhenDataExistsForTheId()
        {
            // Arrange
            TestHarness.ClearEmployeesData(sut);
            var employee = TestDataBuilder.BuildEmployee(1, "emp 1", 25, "SSE", new Address { Town = "town"},
                new Qualification {Graduation = "B.tech"});
            sut.Add(employee);

            // Act
            var emp = sut.Get(employee.Id);
            emp.Designation = "Lead Software Engineer";
            var updatedEmployee = sut.Get(employee.Id);

            // Assert
            updatedEmployee.ShouldNotBeNull();
            updatedEmployee.Id.ShouldBe(1);
            updatedEmployee.Age.ShouldBe(25);
            updatedEmployee.Name.ShouldBe("emp 1");
            updatedEmployee.Designation.ShouldBe("Lead Software Engineer");
            updatedEmployee.Qualification.Graduation.ShouldBe("B.tech");
            updatedEmployee.Address.Town.ShouldBe("town");
        }
    }
}