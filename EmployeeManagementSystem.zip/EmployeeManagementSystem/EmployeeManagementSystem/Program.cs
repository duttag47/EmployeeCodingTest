﻿using System;
using ApplicationCore.Model;
using Infrastructure;
using Infrastructure.DataSourceBuilder;
using Infrastructure.Repository;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;

namespace EmployeeApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = ServiceDependencies.AddSevices();

            using var serviceProvider = services.BuildServiceProvider();
            var employeeResolver =
                serviceProvider.GetService<Func<Source, string, IEmployeeRepository>>();

            #region XMLRepository

            Console.WriteLine(
                $"Start XMLRepository demo {Environment.NewLine}");

            // Creating employee XMLRepository implementation.
            var xmlRepository = employeeResolver(Source.XML, string.Empty);
            AppDemo(xmlRepository);

            Console.WriteLine($"End XMLRepository demo {Environment.NewLine}");

            #endregion XMLRepository

            #region InMenoryRepository

            Console.WriteLine(
                $"Start InMemoryRepository demo {Environment.NewLine}");

            var inMemoryRepository = employeeResolver(Source.InMemory, string.Empty);

            AppDemo(inMemoryRepository);

            Console.WriteLine(
                $"End InMemoryRepository demo {Environment.NewLine}");

            #endregion InMenoryRepository

            Console.ReadLine();
        }

        private static void AppDemo(IEmployeeRepository employeeRepository)
        {
            Console.WriteLine(
                $"Get all pre existing employees --------- Start{Environment.NewLine}");
            var allEmployees = employeeRepository.GetAll();
            Console.WriteLine(
                $"Pre-Existing records {Environment.NewLine}{JsonConvert.SerializeObject(allEmployees, Formatting.Indented)}");
            Console.WriteLine(
                $"Get all pre existing employees --------- End{Environment.NewLine}");

            // Add new employee details
            var emp1 = new Employee
            {
                Id = 1,
                Age = 21,
                Designation = "Software engineer",
                Name = "Employee 1",
                Address = new Address {City = "Delhi"},
                Qualification = new Qualification {Graduation = "B.Tech"}
            };
            employeeRepository.Add(emp1);

            Console.WriteLine(
                $"Employee 1 is added successfully. {Environment.NewLine}");
            allEmployees = employeeRepository.GetAll();
            Console.WriteLine(
                $"Updated result with Employee 1 - {Environment.NewLine}{JsonConvert.SerializeObject(allEmployees, Formatting.Indented)}");

            // Add new employee details
            var emp2 = new Employee
            {
                Id = 2,
                Age = 22,
                Designation = "Designation 2",
                Name = "Employee 2",
                Address = new Address {City = "City 2"},
                Qualification = new Qualification {Graduation = "B.Tech."}
            };
            employeeRepository.Add(emp2);

            Console.WriteLine(
                $"Employee 2 is added successfully {Environment.NewLine}");
            allEmployees = employeeRepository.GetAll();
            Console.WriteLine(
                $"Updated result with Employee 2 - {Environment.NewLine}{JsonConvert.SerializeObject(allEmployees, Formatting.Indented)}");

            // Get employee details by id
            Console.WriteLine(
                $"Get Employee 1 with Id  ---------Start{Environment.NewLine}");
            var employee1Details = employeeRepository.Get(1);
            Console.WriteLine(
                $"Employee 1 details - {Environment.NewLine}{JsonConvert.SerializeObject(employee1Details, Formatting.Indented)}");
            Console.WriteLine(
                $"Get Employee 1 with Id --------- End{Environment.NewLine}");

            // Update age of newly added employee 
            var updatedEmployee = new Employee
            {
                Id = 2,
                Age = 24,
                Designation = "Designation 2 updated",
                Name = "Employee 2",
                Address = new Address {City = "City 2 updated"},
                Qualification = new Qualification {Graduation = "B.Tech."}
            };
            employeeRepository.Update(updatedEmployee);
            Console.WriteLine(
                $"Get all employees after updating Employee 2 age from 22 to 24 --------- Start{Environment.NewLine}");
            allEmployees = employeeRepository.GetAll();
            Console.WriteLine(
                $"Updated result with Employee 2 age {Environment.NewLine}{JsonConvert.SerializeObject(allEmployees, Formatting.Indented)}");

            // Delete Employee with Id equal to 1
            Console.WriteLine(
                $"Delete Employee with Id equal to 1 --------- Start{Environment.NewLine}");
            var employeeId = 1;
            employeeRepository.Delete(employeeId);
            allEmployees = employeeRepository.GetAll();
            Console.WriteLine(
                $"Updated result after deletion {Environment.NewLine}{JsonConvert.SerializeObject(allEmployees, Formatting.Indented)}");
        }
    }
}