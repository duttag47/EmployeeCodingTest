﻿namespace ApplicationCore.Model
{
    public class Address
    {
        /// <summary>
        ///  Gets or Sets the door no
        /// </summary>
        public int DoorNo { get; set; }

        /// <summary>
        ///  Gets or Sets the street
        /// </summary>
        public string Street { get; set; }

        /// <summary>
        ///  Gets or Sets the town
        /// </summary>
        public string Town { get; set; }

        /// <summary>
        ///  Gets or Sets the state
        /// </summary>
        public string State { get; set; }

    }
}