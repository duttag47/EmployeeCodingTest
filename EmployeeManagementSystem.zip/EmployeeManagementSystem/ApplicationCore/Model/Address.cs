﻿namespace ApplicationCore.Model
{
    public class Address
    {
        /// <summary>
        ///     Gets or Sets the city.
        /// </summary>
        public string City { get; set; }
    }
}