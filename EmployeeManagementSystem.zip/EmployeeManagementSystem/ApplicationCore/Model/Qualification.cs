﻿namespace ApplicationCore.Model
{
    public class Qualification
    {
        /// <summary>
        ///     Gets or Sets the graduation
        /// </summary>
        public string Graduation { get; set; }
    }
}