﻿using System;

namespace ApplicationCore.Model
{
    public class Entity
    {
        public int Id { get; set; }

        public DateTime CreatedDate => DateTime.Now;
    }
}