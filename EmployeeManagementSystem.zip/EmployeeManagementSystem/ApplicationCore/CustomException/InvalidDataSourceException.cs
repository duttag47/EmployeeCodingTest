﻿using System;

namespace ApplicationCore.CustomException
{
    public class InvalidDataSourceException : Exception
    {
        public InvalidDataSourceException(string message) : base(message)
        {
        }
    }
}