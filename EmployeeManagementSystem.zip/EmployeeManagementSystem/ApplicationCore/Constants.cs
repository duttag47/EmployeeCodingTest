﻿namespace ApplicationCore
{
    public class FileExtension
    {
        public const string XmlFileType = ".xml";
    }
}